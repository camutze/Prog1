/* acrescente demais includes que voce queira ou precise */
#include "racionais.h"

/* 
 * Implemente neste arquivo as funções definidas no racionais.h.
 * Caso queira, você pode definir neste arquivo funções adicionais
 * que serão internas a este arquivo.
 *
 * Por exemplo, as funções aleat, mdc e mmc devem ser
 * implementadas neste arquivo.
*/

/* retorna um numero aleatorio entre min e max, inclusive. */
int aleat (int min, int max){
/* coloque o codigo aqui */
}

/* Maximo Divisor Comum entre a e b      */
/* calcula o mdc pelo metodo de Euclides */
int mdc (int a, int b){
/* coloque o codigo aqui */
}

/* Minimo Multiplo Comum entre a e b */
/* mmc = (a * b) / mdc (a, b)        */
int mmc (int a, int b){
/* coloque o codigo aqui */
}

/* implemente aqui as funções declaradas em racionais.h */

