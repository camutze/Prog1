/* Arquivo MAIN que usa o TAD racionais */

/* coloque seus includes aqui */

int main ()
{

    /* coloque seu código aqui */

    return 0;
}
